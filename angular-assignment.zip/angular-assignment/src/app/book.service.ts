import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { IBook } from "./book";
import { Observable } from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class BookService {

  private _url: string = "http://localhost:3000/books";
// private _url: string = "./assets/db/data.json";
  constructor(private http: HttpClient) { }
  getBooks(): Observable<IBook[]>{
    return this.http.get<IBook[]>(this._url);
  }

  setBooks(bookObj){
      return this.http.post(this._url, bookObj);
  }

  getBookById(id: string): Observable<IBook>{
    return this.http.get<IBook>(this._url + "/"+id);
  }

  updateBook(bookObj, id: string) {
    return this.http.put<IBook>(this._url + "/" +id, bookObj)
}

  // viewBooks()

}
