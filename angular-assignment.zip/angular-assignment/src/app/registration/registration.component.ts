import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from "@angular/forms";

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  checkoutForm: FormGroup;


  // isShown: boolean = false;
  // toggle

  public publishers: any = ['CSE', 'ECE', 'EEE', 'ITE', 'MECH']
  constructor(private formBuilder:FormBuilder) {



    this.checkoutForm= formBuilder.group({
      'studentName': ['', [Validators.required, Validators.minLength(3)]],
      'studentEmail': ['', [Validators.required, Validators.email]],
      'phoneNo': ['', [Validators.required, Validators.pattern('[0-9]{10}')]],
      'password': ['', Validators.required],
      // 'isbn': ['', [Validators.required, Validators.minLength(10), Validators.maxLength(15)]],
      'hostelCheck': [''],
      'publishersName': ['', Validators.required],
      'studentAddress': ['', Validators.maxLength(30)]

      // 'quantity': ['', Validators.required],
      // 'terms': ['', Validators.requiredTrue]
    });
  }

  changePublisher(e) {
    this.publishersName.setValue(e.target.value, {
      onlySelf: true
    })
  }

  get publishersName(){
    return this.checkoutForm.get('publishersName')
  }

  ngOnInit(): void {
  }
  postData(){
    console.log(this.checkoutForm);
    console.log("Entire value"+this.checkoutForm.value);
    // console.log("Email Address"+this.checkoutForm.value.emailAddr);
  }
}
