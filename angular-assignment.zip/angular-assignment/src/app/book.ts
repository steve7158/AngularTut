export interface IBook{
  id: number,
  book_title: string,
  author: string,
  publicationYear: string
}
