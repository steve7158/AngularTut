import { Component, OnInit } from '@angular/core';
import { BookService } from "../../book.service";
import { Router, ActivatedRoute, ParamMap } from "@angular/router";
@Component({
  selector: 'app-book-overview',
  templateUrl: './book-overview.component.html',
  styleUrls: ['./book-overview.component.scss']
})
export class BookOverviewComponent implements OnInit {
  public books = [];
  public selectedId;
  constructor(private router: Router, private route: ActivatedRoute, private _bookService: BookService) { }

  onSelect(book){
    this.router.navigate(['/book-management/book-details' ,book.id]);
  }

  ngOnInit(): void {
    this._bookService.getBooks().subscribe(data=>this.books = data);

    // this.route.paramMap.subscribe((params: ParamMap)=>{
    //   let id = parseInt(params.get())
    // })
  }


}
