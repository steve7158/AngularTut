import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BookManagementRoutingModule } from './book-management-routing.module';
import { BookDetailsComponent } from './book-details/book-details.component';
import { BookOverviewComponent } from './book-overview/book-overview.component';
import { BookService } from "../book.service";
import { HttpClientModule } from "@angular/common/http";
import { AddBookComponent } from './add-book/add-book.component';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

@NgModule({
  declarations: [BookDetailsComponent, BookOverviewComponent, AddBookComponent],
  imports: [
    CommonModule,
    BookManagementRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    BookService,
  ]
})
export class BookManagementModule { }
