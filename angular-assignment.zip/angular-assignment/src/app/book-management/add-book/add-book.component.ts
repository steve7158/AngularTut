import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators,ReactiveFormsModule } from "@angular/forms";
import { BookService } from "../../book.service";

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.scss']
})
export class AddBookComponent implements OnInit {

  addBookForm: FormGroup;

  // public employees = [];

  constructor(private formBuilder: FormBuilder, private _bookservice: BookService) {
    this.addBookForm = formBuilder.group({
      'book_title': ['', Validators.required],
      'author': ['', Validators.required],
      'id': [0, Validators.required],
      'publicationYear': ['', Validators.required]
    });
  }

  msgTrue = false;
  addBook(){
    console.log(this.addBookForm.value);
    // this._employee = {name: this.addUserForm.value.name, age: Number(this.addUserForm.value.age), id: Number(this.addUserForm.value.id)};
    this._bookservice.setBooks(this.addBookForm.value).subscribe(data=>{console.log(data);
    this.msgTrue =true;});

  }

  ngOnInit(): void {
  }
}
