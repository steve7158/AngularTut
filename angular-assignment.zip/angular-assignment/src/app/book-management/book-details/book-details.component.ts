import { Component, OnInit } from '@angular/core';
import { BookService } from "../../book.service";
import { ActivatedRoute, Router, ParamMap } from "@angular/router";
@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.scss']
})
export class BookDetailsComponent implements OnInit {
  public book;
  public bookId;

  constructor(private route: ActivatedRoute, private router: Router ,private _bookService: BookService) { }

  ngOnInit(): void {
    this.route.paramMap.subscribe((params: ParamMap)=>{
      let id = params.get('id');
      this.bookId = id
    });
    this._bookService.getBookById(this.bookId).subscribe(data=>this.book = data);
  }

}
