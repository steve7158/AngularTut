import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './welcome/welcome.component';
import { RegistrationComponent } from './registration/registration.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';

const routes: Routes = [
  {path: '', redirectTo: '/welcome', pathMatch:'full'},
  {path: 'welcome', component: WelcomeComponent},
  {path: 'register', component: RegistrationComponent},
  {path: 'book-management', loadChildren: ()=>import('./book-management/book-management.module').then(mod=>mod.BookManagementModule)},
  {path: '**', component: PageNotFoundComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
